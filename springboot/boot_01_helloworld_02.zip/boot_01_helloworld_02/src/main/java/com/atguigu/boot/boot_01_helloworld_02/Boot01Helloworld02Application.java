package com.atguigu.boot.boot_01_helloworld_02;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Boot01Helloworld02Application {

    public static void main(String[] args) {
        SpringApplication.run(Boot01Helloworld02Application.class, args);
    }

}
